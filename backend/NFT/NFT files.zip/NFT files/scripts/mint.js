const { ethers } = require("hardhat");

async function main() {
  const PropertyRegistration = await ethers.getContractFactory("PropertyRegistration");
  const propertyRegistration = await PropertyRegistration.attach("CONTRACT_ADDRESS");

  const propertyName = "My Property";
  const propertyLocation = "Location";

  const transaction = await propertyRegistration.registerProperty(propertyName, propertyLocation);
  await transaction.wait();

  console.log("Property registered successfully!");
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });