const main = async () => {
  const Transactions = await hre.ethers.getContractFactory("Transactions");
  const PropertyRegistration = await hre.ethers.getContractFactory("PropertyRegistration");

  console.log("Deploying, please wait.");

  const transactions = await Transactions.deploy();
  await transactions.deployed();

  const propertyRegistration = await PropertyRegistration.deploy("https://your-base-uri.com/");
  await propertyRegistration.deployed();

  console.log(`Transactions contract deployed to ${transactions.address}`);
  console.log(`PropertyRegistration contract deployed to ${propertyRegistration.address}`);
};

const runMain = async () => {
  try {
    await main();
    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

runMain();