const { ethers } = require("hardhat");

async function main() {
  const PropertyRegistration = await ethers.getContractFactory("PropertyRegistration");
  const propertyRegistration = await PropertyRegistration.attach("CONTRACT_ADDRESS");

  const registrationCount = await propertyRegistration.getRegistrationCount();
  console.log("Registration Count:", registrationCount.toNumber());

  const tokenId = 1;
  const property = await propertyRegistration.getProperty(tokenId);
  console.log("Property Details:", property);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });