---
'openzeppelin-solidity': patch
---

`TransparentUpgradeableProxy`: Make internal `_proxyAdmin()` getter have `view` visibility.
