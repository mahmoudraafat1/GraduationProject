---
'openzeppelin-solidity': minor
---

`Panic`: Add a library for reverting with panic codes.
