---
'openzeppelin-solidity': minor
---

`ERC1363`: Add implementation of the token payable standard allowing execution of contract code after transfers and approvals.
