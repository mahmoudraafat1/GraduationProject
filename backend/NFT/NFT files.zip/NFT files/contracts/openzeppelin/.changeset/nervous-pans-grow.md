---
'openzeppelin-solidity': patch
---

`SafeCast`: Add `toUint(bool)` for operating on `bool` values as `uint256`.
